# Avenor 3.0 — Swift Playgrounds app

Open **Avenor.swiftpm** in **Swift Playgrounds** (iPad or Mac, version 4.4 or later) or in **Xcode 15+**, then press **Run** (▶).

- Requires iOS / iPadOS 17 or later.
- The source is the same as the iOS v03 Xcode project, flattened into one app module.
- Before submitting to TestFlight or the App Store, change `bundleIdentifier` in `Package.swift` to your own. `teamIdentifier` is copied from your Xcode project.
- The tip jar shows "unavailable" until the three in-app purchase IDs in `YouScreen.swift` exist in App Store Connect.
- Reminders work normally. On first use, iOS asks for notification permission.
