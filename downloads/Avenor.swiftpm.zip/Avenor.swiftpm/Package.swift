// swift-tools-version: 5.9

// Avenor 3.0 as a Swift Playgrounds app package (.swiftpm).
// Opens in Swift Playgrounds 4.4+ on iPad or Mac, and in Xcode 15+.

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "Avenor",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "Avenor",
            targets: ["AppModule"],
            bundleIdentifier: "com.avenorteam.avenor",
            teamIdentifier: "2825WL2A87",
            displayVersion: "3.0",
            bundleVersion: "3",
            appIcon: .asset("AppIcon"),
            accentColor: .asset("AccentColor"),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ],
            appCategory: .education
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            exclude: ["README.md"]
        )
    ]
)
